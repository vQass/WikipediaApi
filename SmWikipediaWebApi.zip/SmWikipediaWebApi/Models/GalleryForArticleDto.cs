﻿namespace SmWikipediaWebApi.Models
{
    public class GalleryForArticleDto
    {
        public string ImagePath { get; set; }
        public string ImageDescription { get; set; }
    }
}
