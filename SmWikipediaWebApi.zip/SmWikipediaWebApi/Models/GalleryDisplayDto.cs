﻿namespace SmWikipediaWebApi.Models
{
    public class GalleryDisplayDto
    {
        public int Id { get; set; }
        public string ArticleName { get; set; }
        public string ImagePath { get; set; }
        public string ImageDescription { get; set; }
    }
}