﻿namespace SmWikipediaWebApi.Models
{
    public class ArticleContentForArticleDto
    {
        public string SectionName { get; set; }
        public string Content { get; set; }
    }
}
