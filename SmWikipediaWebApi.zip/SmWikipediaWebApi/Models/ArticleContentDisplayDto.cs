﻿namespace SmWikipediaWebApi.Models
{
    public class ArticleContentDisplayDto
    {
        public int Id { get; set; }
        public string ArticleName { get; set; }
        public string SectionName { get; set; }
        public string Content { get; set; }
    }
}
